<?php
header("Access-Control-Allow-Origin:*");

// Inclure les fonctions :
require_once('./functions.php');
// echo "<pre>";
// var_dump($_SERVER);
// echo "</pre>";
// die;

if ($_SERVER['REQUEST_METHOD'] == "GET") {
    $url = $_SERVER["REQUEST_URI"]; // explications mitra
    // var_dump('URL 1 : ' . $url);
    $url = trim($url, "\/");

    // var_dump('URL 2 : ' . $url);
    $url = explode("/", $url);
    $string1 = explode(".", 'Jeremy.Alexis.Cynthia.Michel');

    // var_dump('string1 : ' . $string1[0]);
    // var_dump('URL 3 : ' . $url);
    $action = $url[0];
    $listproduit = $url[1];

    // var_dump('action  : ' . $action);

    // die;
    if ($action) { // explications MITRA 
        findAll();
    } else {
        echo json_encode([
            "status" => 404,
            "message" => "grosse erreur"
        ]);
    }
} else {
    // On récupère les informations du "formulaire" de route.rest dans la variable data
    $data = json_decode(file_get_contents("php://input"), true); // Permet de récupérer le contenu du fichier dans $data
    // var_dump($data);
    // die;
    if ($data["action"] == "produits") {
        // On appelle la fonction produits
        produits($data['nom'], $data['description'], $data['prix'], $data['categories_id']);
    } elseif ($data["action"] == "update") {
        update($data['id'], $data['nom'], $data['description'], $data['prix'], $data['categories_id']);
    } else {
        json_encode([
            "status" => 404,
            "message" => "Votre requête a échouée"
        ]);
    }
}
